export const paths = {
  home: '/',
  reviews: '/reviews',
  photoGallery: '/photo-gallery',
  news: '/news',
  delivery: '/delivery',
  contacts: '/contacts',
  policy: '/policy',
  about: '/about',
  certificate: '/certificate',
  catalog: '/catalog',
};
