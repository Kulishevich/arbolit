import { Ref, SVGProps, forwardRef, memo } from 'react';

const LocationIcon = (
  props: SVGProps<SVGSVGElement>,
  ref: Ref<SVGSVGElement>
) => (
  <svg
    width="26"
    height="26"
    ref={ref}
    {...props}
    viewBox="0 0 26 26"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M13 0C7.61556 0 3.25 4.36556 3.25 9.75C3.25 11.8702 3.94509 13.8158 5.10047 15.4091C5.12119 15.4473 5.12444 15.4899 5.148 15.5265L11.648 25.2765C11.9494 25.7286 12.4572 26 13 26C13.5428 26 14.0506 25.7286 14.352 25.2765L20.852 15.5265C20.876 15.4899 20.8788 15.4473 20.8995 15.4091C22.0549 13.8158 22.75 11.8702 22.75 9.75C22.75 4.36556 18.3844 0 13 0ZM13 13C11.2052 13 9.75 11.5448 9.75 9.75C9.75 7.95519 11.2052 6.5 13 6.5C14.7948 6.5 16.25 7.95519 16.25 9.75C16.25 11.5448 14.7948 13 13 13Z"
      fill="#E8E8E7"
    />
  </svg>
);
const ForwardRef = forwardRef(LocationIcon);
const Memo = memo(ForwardRef);

export default Memo;
