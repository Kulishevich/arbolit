export * from './NewsCard';
